package videoRecording;

import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class VideoRec
{
public static ATUTestRecorder rec;
	public static void videoRec(String name) throws ATUTestRecorderException
	{
	/*SimpleDateFormat s=new SimpleDateFormat("dd_MM_YYYY hh_mm_ss");
	Date date=new Date();
	String str=s.format(date);*/
	rec=new ATUTestRecorder("C:\\Users\\hp\\Desktop\\VideoRec",name, false);
	}
}
