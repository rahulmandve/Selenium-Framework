package ExcelSheetReader;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReadExcelData {
	
	XSSFWorkbook book;
	XSSFSheet sheet;
	
	public ReadExcelData(String excelpath) 
	{	
		
		try {
			File src=new File(excelpath);
			FileInputStream fis=new FileInputStream(src);
			book=new XSSFWorkbook(fis);
		} catch (Exception e) {
			System.out.println(e);
		}
		
	}
	public String getData(int sheetnumber,int row,int column)
	{
		sheet=book.getSheetAt(sheetnumber);
		String data=sheet.getRow(row).getCell(column).getStringCellValue();
		return data;
	}
	public int getRowCount(int sheetIndex)
	{
		int row=book.getSheetAt(sheetIndex).getLastRowNum()+1;
		return row;
	}
	

}
