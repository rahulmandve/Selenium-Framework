package Driver;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import Utility.ReadConfigFile;
import atu.testrecorder.exceptions.ATUTestRecorderException;



public class LounchBrowser{
	
	ReadConfigFile rd=new ReadConfigFile();
	public static WebDriver d;
	
	@BeforeMethod
	public  void OpenBrowser() throws Exception
	{	
		System.setProperty("webdriver.chrome.driver",rd.getChromePath());
		d=new ChromeDriver();
		d.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		d.get(rd.getWebSiteURL());
		Thread.sleep(2000);
		d.manage().window().maximize();
		
	}
	@AfterMethod
	public void closeBrowser() throws ATUTestRecorderException
	{
		d.quit();
		
	}

}
