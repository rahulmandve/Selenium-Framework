package Utility;

import java.io.FileInputStream;
import java.util.Properties;

public class ReadConfigFile {
	Properties pro;
	public ReadConfigFile()
	{
		try {
			FileInputStream fis=new FileInputStream("./Config/Config.property");//getClass();
			pro=new Properties();
			pro.load(fis);
		} catch (Exception e) {
			System.out.println("Exception"+e.getMessage());
		}
	}
	public String getChromePath()
	{
		return  pro.getProperty("ChromeURL");
	}
	public String getWebSiteURL()
	{
		return pro.getProperty("WebSiteURl");
	}
	public String getUname()
	{
		return pro.getProperty("Uname");
	}
	public String getpass()
	{
		return pro.getProperty("pass");
	}
	public String getClickButton()
	{
		return pro.getProperty("click");
	}
	
}
